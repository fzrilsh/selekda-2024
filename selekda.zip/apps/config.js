export const config = {
    env: 'production'
}