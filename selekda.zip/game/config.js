export const config = {
    env: 'production',
    serverUrl: 'https://selekda.fazrilsh.my.id/server'
}