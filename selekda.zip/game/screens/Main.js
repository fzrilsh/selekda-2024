import Countdown from "./views/Countdown.js"
import Gameboard from "./views/Gameboard.js"
import Register from "./views/Register.js"

class ScreenController {
    constructor(){
        this.current = null

        this.register = new Register()
        this.countdown = new Countdown()
        this.gameboard = new Gameboard()

        this.user = JSON.parse(localStorage.getItem('user') ?? '{}')
    }

    init(){
        this.change('register')
    }

    change(screen){
        if(this.current) this.current.unMount()

        this.current = this[screen]
        this.current.mount()
    }
}

export const screenController = new ScreenController()