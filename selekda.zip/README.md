# Repository
Github: [selekda-2024](https://github.com/fzrilsh/selekda-2024) (main)
Hosting: [selekda](https://selekda.fazrilsh.my.id/)

# Information
1. please change server base url in front_end development and game, the default is: https://selekda.fazrilsh.my.id/server
2. Zip url: https://selekda.fazrilsh.my.id/selekda.zip